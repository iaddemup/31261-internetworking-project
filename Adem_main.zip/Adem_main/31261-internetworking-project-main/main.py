import igraph
from igraph import Graph

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import global_mean_pool, GCN, SAGEConv, Node2Vec
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader

import pickle
import pandas as pd

from sklearn.preprocessing import StandardScaler
import numpy as np
import joblib

# ------------------ seeds ------------------
seed = 31261
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
np.random.seed(seed)

# ------------------ data load ------------------
OCBdataset = pickle.load(open(r"data\ckt_bench_101.pkl", 'rb'))
csv = pd.read_csv(r"data\perform101.csv")
trainingDataset = OCBdataset[0]
testingDataset = OCBdataset[1]

# ------------------ GraphDataset ------------------
class GraphDataset(Data):
    def __init__(self, c=None, gm=None, pos=None, r=None, type=None, vid=None, edge_index=None, y=None):
        super().__init__(edge_index=edge_index, y=y)
        self.c = c
        self.gm = gm
        self.pos = pos
        self.r = r
        self.type = type
        self.vid = vid
        self.cat_feat = None  # optional precomputed categorical feature (e.g., node2vec)

# ------------------ find max node types ------------------
max_node_types = 0
for (richGraph, _) in trainingDataset + testingDataset:
    max_node_types = max(max_node_types, max(richGraph.vs['type']))
max_node_types += 1

# ------------------ fit node scaler ------------------
node_features_train = []
for (richGraph, simpleGraph) in trainingDataset:
    features = np.column_stack([
        richGraph.vs['c'],
        richGraph.vs['gm'],
        richGraph.vs['pos'],
        richGraph.vs['r'],
        richGraph.vs['vid']
    ])
    node_features_train.append(features)
node_features_train = np.vstack(node_features_train)
node_scaler = StandardScaler()
node_scaler.fit(node_features_train)

# ------------------ fit y scaler ------------------
y_scaler = StandardScaler()
y_train = csv.iloc[:len(trainingDataset)][['gain', 'pm', 'bw', 'fom']]
y_scaler.fit(y_train)

# ------------------ Data builder (original numeric + optional cat_feat) ------------------
def buildData_with_cat(dataset, cat_feat_list=None, start_idx=0):
    out = []
    for i, (richGraph, simpleGraph) in enumerate(dataset):
        features = np.column_stack([
            richGraph.vs['c'],
            richGraph.vs['gm'],
            richGraph.vs['pos'],
            richGraph.vs['r'],
            richGraph.vs['vid']
        ])
        features = node_scaler.transform(features)
        c, gm, pos, r, vid = [torch.tensor(features[:, j], dtype=torch.float32) for j in range(5)]

        type_t = torch.tensor(richGraph.vs['type'], dtype=torch.long)

        el = richGraph.get_edgelist()
        if len(el) == 0:
            edge_index = torch.empty((2, 0), dtype=torch.long)
        else:
            edge_index = torch.tensor(el, dtype=torch.long).t().contiguous()

        csv_idx = start_idx + i
        y_values = csv.loc[csv_idx, ['gain', 'pm', 'bw', 'fom']].values.reshape(1, -1)
        y_values_df = pd.DataFrame(y_values, columns=['gain', 'pm', 'bw', 'fom'])
        y_norm = y_scaler.transform(y_values_df)
        y = torch.tensor(y_norm, dtype=torch.float32)

        gd = GraphDataset(c=c, gm=gm, pos=pos, r=r, type=type_t, vid=vid, edge_index=edge_index, y=y)
        if cat_feat_list is not None:
            # ensure tensor type
            gd.cat_feat = torch.tensor(cat_feat_list[i], dtype=torch.float32)
        else:
            gd.cat_feat = None
        out.append(gd)
    return out

# ------------------ initial small dataloaders (not used in sweep but keep for compatibility) ------------------
gTrain = buildData_with_cat(trainingDataset, cat_feat_list=None, start_idx=0)
gTest = buildData_with_cat(testingDataset, cat_feat_list=None, start_idx=len(trainingDataset))

batch_size = 128
# these will be re-created per embedding mode in sweep
trainDataloader = DataLoader(gTrain, batch_size, shuffle=True)
testDataloader = DataLoader(gTest, batch_size)

# ------------------ GNN model (supports gcn and graphsage; accepts optional external cat_feat) ------------------
class GNN(nn.Module):
    def __init__(self, hidden_dim, num_layers, activation="relu", encoder="gcn", cat_out_dim=None):
        super().__init__()
        self.encoder_type = encoder
        # If external categorical features are provided, set cat_out_dim accordingly.
        if cat_out_dim is None:
            # project one-hot into hidden_dim
            self.linear1 = nn.Linear(max_node_types, hidden_dim)
            cat_out_dim = hidden_dim
            self.use_external_cat = False
        else:
            self.use_external_cat = True

        self.linear2 = nn.Linear(5, hidden_dim)
        combined_dim = cat_out_dim + hidden_dim

        if self.encoder_type == "gcn":
            self.encoder = GCN(combined_dim, hidden_dim, num_layers, dropout=0.4, norm='batchnorm')
        elif self.encoder_type == "graphsage":
            self.sage_convs = nn.ModuleList()
            in_dim = combined_dim
            for _ in range(num_layers):
                self.sage_convs.append(SAGEConv(in_dim, hidden_dim))
                in_dim = hidden_dim
        else:
            raise ValueError("Unknown encoder type")

        act_map = {
            "relu": nn.ReLU(),
            "leaky_relu": nn.LeakyReLU(),
            "elu": nn.ELU(),
            "gelu": nn.GELU(),
        }
        self.activation = act_map[activation]
        self.out = nn.Linear(hidden_dim, 4)

    def forward(self, batch_data, device):
        if hasattr(batch_data, "cat_feat") and batch_data.cat_feat is not None:
            x_t = batch_data.cat_feat.to(batch_data.c.device).to(torch.float32)
        else:
            x_t = F.one_hot(batch_data.type, max_node_types).to(torch.float32).to(batch_data.c.device)
            x_t = self.linear1(x_t)

        x_num = torch.stack([batch_data.c, batch_data.gm, batch_data.pos, batch_data.r, batch_data.vid], dim=-1).to(torch.float32)
        x_num = self.linear2(x_num.to(x_t.device))

        z = torch.cat((x_t, x_num), dim=-1)

        e = batch_data.edge_index.to(x_t.device)

        if self.encoder_type == "gcn":
            z = self.encoder(z, e)
            z = self.activation(z)
        else:
            for conv in self.sage_convs:
                z = conv(z, e)
                z = self.activation(z)

        z = global_mean_pool(z, batch_data.batch.to(x_t.device))
        pred = self.out(z)
        return pred

# ------------------ train and test functions (standalone) ------------------
def train_epoch(dataloader, model, loss_fn, optimizer, device):
    model.train()
    size = len(dataloader.dataset)
    epoch_loss = 0.0
    num_batches = 0

    for i, batch_data in enumerate(dataloader):
        batch_data = batch_data.to(device)

        optimizer.zero_grad()
        pred = model(batch_data, device)
        loss = loss_fn(pred, batch_data.y.to(pred.device))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        epoch_loss += loss.item()
        num_batches += 1

        if (i + 1) % 70 == 0:
            loss_val, current = loss.item(), (i + 1) * len(batch_data)
            print(f"Loss: {loss_val:>7f}  [{current:>5d}/{size:>5d}]")

    return epoch_loss / num_batches if num_batches > 0 else 0.0

def test_epoch(dataloader, model, loss_fn, device):
    model.eval()
    num_batches = len(dataloader)
    total_loss = 0.0

    with torch.no_grad():
        for i, batch_data in enumerate(dataloader):
            batch_data = batch_data.to(device)
            pred = model(batch_data, device)
            loss = loss_fn(pred, batch_data.y.to(pred.device))
            total_loss += loss.item()

    avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
    print(f"Test Loss ({loss_fn.__class__.__name__}): {avg_loss:.6f}")
    return avg_loss

# ------------------ device and hyperparams ------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

activations = ["relu", "leaky_relu", "elu", "gelu"]

MSE = nn.MSELoss()
def rMSE(pred, batch_data):
    return torch.sqrt(MSE(pred, batch_data))
MAE = nn.L1Loss()
Huber = nn.HuberLoss(delta=1.0)

loss_functions = {
    "MSE": MSE,
    "rMSE": rMSE,
    "MAE": MAE,
    "Huber": Huber
}

optimisers = {
    "SGD" : torch.optim.SGD,
    "RMSprop" : torch.optim.RMSprop,
    "ADAM" : torch.optim.Adam,
    "ADAMw" : torch.optim.AdamW
}

# ------------------ Node2Vec precompute (concatenate graphs, split back) ------------------
def prepare_node2vec_embeddings(datasets, embedding_dim=64, walk_length=20, context_size=10, walks_per_node=10, epochs=5, lr=0.01, device=None):
    edge_list = []
    node_counts = []
    total_nodes = 0
    for (rg, sg) in datasets:
        n = len(rg.vs)
        node_counts.append(n)
        el = np.array(rg.get_edgelist(), dtype=np.int64)
        if el.size > 0:
            el_offset = el + total_nodes
            edge_list.append(el_offset)
        total_nodes += n
    if total_nodes == 0:
        raise RuntimeError("No nodes for Node2Vec")
    if len(edge_list) == 0:
        edge_index = torch.empty((2,0), dtype=torch.long)
    else:
        edge_index = torch.tensor(np.vstack(edge_list).T, dtype=torch.long).contiguous()

    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    node2vec = Node2Vec(edge_index, embedding_dim=embedding_dim, walk_length=walk_length,
                        context_size=context_size, walks_per_node=walks_per_node, sparse=True).to(device)

    loader = node2vec.loader(batch_size=128, shuffle=True, num_workers=0)
    optimizer = torch.optim.SparseAdam(list(node2vec.parameters()), lr=lr)

    node2vec.train()
    for epoch in range(epochs):
        total_loss = 0.0
        for pos_rw, neg_rw in loader:
            pos_rw = pos_rw.to(device)
            neg_rw = neg_rw.to(device)
            optimizer.zero_grad()
            loss = node2vec.loss(pos_rw, neg_rw)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Node2Vec epoch {epoch+1}/{epochs} loss {total_loss:.4f}")

    node2vec.eval()
    with torch.no_grad():
        emb_all = node2vec.embedding.weight.detach().cpu()

    embeddings_per_graph = []
    start = 0
    for n in node_counts:
        embeddings_per_graph.append(emb_all[start:start+n].clone())
        start += n

    return embeddings_per_graph

# ------------------ sweep: onehot, graphsage, node2vec ------------------
embedding_modes = ["onehot", "graphsage", "node2vec"]

print("Preparing Node2Vec embeddings (this may take a little while)...")
all_graphs = trainingDataset + testingDataset
node2vec_embeddings = prepare_node2vec_embeddings(all_graphs, embedding_dim=64, epochs=3, device=device)
node2vec_train = node2vec_embeddings[:len(trainingDataset)]
node2vec_test = node2vec_embeddings[len(trainingDataset):]

results = []
best_test_loss = float('inf')
best_config = None

for embedding_mode in embedding_modes:
    print(f"\n--- Embedding mode: {embedding_mode} ---")

    if embedding_mode == "onehot":
        gTrain_mode = buildData_with_cat(trainingDataset, cat_feat_list=None, start_idx=0)
        gTest_mode = buildData_with_cat(testingDataset, cat_feat_list=None, start_idx=len(trainingDataset))
        cat_arg = None
        encoder_type = "gcn"
    elif embedding_mode == "graphsage":
        gTrain_mode = buildData_with_cat(trainingDataset, cat_feat_list=None, start_idx=0)
        gTest_mode = buildData_with_cat(testingDataset, cat_feat_list=None, start_idx=len(trainingDataset))
        cat_arg = None
        encoder_type = "graphsage"
    elif embedding_mode == "node2vec":
        gTrain_mode = buildData_with_cat(trainingDataset, cat_feat_list=node2vec_train, start_idx=0)
        gTest_mode = buildData_with_cat(testingDataset, cat_feat_list=node2vec_test, start_idx=len(trainingDataset))
        cat_arg = node2vec_train[0].shape[1] if len(node2vec_train) > 0 else 64
        encoder_type = "gcn"
    else:
        raise ValueError("Unknown embedding mode")

    trainLoader = DataLoader(gTrain_mode, batch_size=batch_size, shuffle=True)
    testLoader = DataLoader(gTest_mode, batch_size=batch_size)

    for opt_name, opt_class in optimisers.items():
        for loss_name, loss_func in loss_functions.items():
            for act_name in activations:
                torch.manual_seed(seed)
                torch.cuda.manual_seed(seed)
                np.random.seed(seed)

                print(f"\nTesting: embed={embedding_mode}, {opt_name}, {loss_name}, {act_name}")
                model = GNN(hidden_dim=128, num_layers=3, activation=act_name, encoder=encoder_type, cat_out_dim=cat_arg).to(device)
                optimiser = opt_class(model.parameters(), lr=5e-4)

                for epoch in range(5):
                    _ = train_epoch(trainLoader, model, loss_func, optimiser, device)

                val_loss = test_epoch(testLoader, model, loss_func, device)
                results.append((embedding_mode, opt_name, loss_name, act_name, val_loss))

                if val_loss < best_test_loss:
                    best_test_loss = val_loss
                    best_config = (embedding_mode, opt_name, loss_name, act_name)

# ------------------ summary ------------------
import matplotlib.pyplot as plt
from collections import defaultdict

# --- Plain-text summary (unchanged) ---
print("\n=== Summary of All Tests ===")
for r in results:
    print(f"Embedding={r[0]}, Optimizer={r[1]}, Loss={r[2]}, Activation={r[3]}, ValLoss={r[4]:.6f}")

if best_config is not None:
    print(f"\nBest configuration: Embedding={best_config[0]}, Optimizer={best_config[1]}, Loss={best_config[2]}, Activation={best_config[3]}, ValLoss={best_test_loss:.6f}")
else:
    print("\nNo successful runs recorded.")

# --- Plotting: one figure per embedding ---
results_by_embedding = defaultdict(list)
for emb, opt, loss, act, val in results:
    label = f"{opt}\n{loss}\n{act}"
    results_by_embedding[emb].append((label, val))

for emb, entries in results_by_embedding.items():
    labels = [e[0] for e in entries]
    vals = [e[1] for e in entries]

    # optional: sort ascending by loss for readability
    order = sorted(range(len(vals)), key=lambda i: vals[i])
    labels_sorted = [labels[i] for i in order]
    vals_sorted = [vals[i] for i in order]

    width_inches = max(8, min(24, 0.5 * len(labels_sorted)))
    plt.figure(figsize=(width_inches, 6))
    bars = plt.bar(range(len(vals_sorted)), vals_sorted, color='C0')

    plt.xticks(range(len(labels_sorted)), labels_sorted, rotation=45, ha='right', fontsize=10)
    plt.ylabel("Validation Loss")
    plt.title(f"Validation Losses — Embedding: {emb}")
    plt.grid(axis='y', alpha=0.3)

    # annotate bars with value
    ylim_top = max(vals_sorted) if len(vals_sorted) > 0 else 1.0
    for i, v in enumerate(vals_sorted):
        plt.text(i, v + 0.002 * ylim_top, f"{v:.4f}", ha='center', va='bottom', fontsize=8)

    plt.tight_layout()
    out_fname = f"results_{emb}.png"
    plt.savefig(out_fname, dpi=150)
    print(f"Saved plot: {out_fname}")
    plt.show()